(1) Download CIFAR-10 from https://www.cs.toronto.edu/~kriz/cifar.html.

(2) Unpack the compressed file to this folder so that this folder directly contains binary files
